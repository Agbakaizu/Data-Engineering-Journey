# 🎓 Data Engineering Journey
### By Dorcas Agbakaizu | April 2026

---

## 📖 About This Repository

This repository documents my complete SQL and Python learning journey from absolute zero to job-ready data engineering skills.

Every query, project and concept here was written independently after learning from scratch — no prior technical background.

---

## 📁 Repository Structure

```
data-engineering-journey/
├── SQL/
│   ├── day1_basics.sql
│   ├── day2_to_day4_students_db.sql
│   ├── day5_to_day7_hospital_db.sql
│   └── hospital_capstone_project.sql
├── Python/
│   └── (coming soon)
├── Projects/
│   └── (coming soon)
└── README.md
```

---

## 🗄️ SQL — What I Learned

### Days 1-4: Foundations
| Concept | Description |
|---|---|
| SELECT, FROM, AS | Basic querying and aliasing |
| WHERE | Filtering rows by condition |
| AND / OR | Multiple conditions |
| ORDER BY | Sorting results |
| BETWEEN & LIKE | Range and pattern filtering |
| COUNT, AVG, MIN, MAX | Aggregate functions |
| GROUP BY & HAVING | Grouping and filtering groups |
| INSERT, UPDATE, DELETE | Data manipulation |
| PRIMARY KEY | Preventing duplicate data |

### Days 5-7: Advanced SQL
| Concept | Description |
|---|---|
| INNER JOIN | Only matching rows from both tables |
| LEFT JOIN | All left rows + matches from right |
| RIGHT JOIN | All right rows + matches from left |
| Aliases | Shortening table names in queries |
| Subqueries | Queries nested inside other queries |
| CASE WHEN | Conditional logic in SQL |
| CTEs | Temporary named query results |
| ROW_NUMBER & RANK | Window functions for ranking |
| PARTITION BY | Ranking within groups |
| Views | Saved reusable virtual tables |
| Stored Procedures | Saved reusable code blocks with parameters |

---

## 🏥 Hospital Database Project

A complete hospital patient management system built from scratch demonstrating all SQL concepts:

- **2 tables:** patients, appointments
- **7 patients** with conditions and demographics
- **6 appointments** across different doctors and statuses
- Complex queries combining JOINs, CTEs, Window Functions, CASE WHEN and Subqueries

### Key Highlights:
- Doctor performance summary using conditional SUM
- Patient priority dashboard using CASE WHEN inside ORDER BY
- Appointment tracking with stored procedures
- City-specific subquery analysis

---

## 🐍 Python — What I Learned

| Concept | Description |
|---|---|
| Variables & Data Types | str, int, float, bool |
| String Operations | f-strings, upper(), len(), concat |
| Math Operations | +, -, *, /, //, %, ** |
| Lists | Collections, indexing, append, remove |
| Dictionaries | Key-value pairs, accessing, updating |
| If/Else | Conditional logic |
| For Loops | Iterating through collections |
| Functions | def, parameters, return, docstrings |
| Lambda Functions | One-line functions |
| *args & **kwargs | Variable arguments |
| File Handling | Reading and writing text files |
| Pandas | DataFrames, filtering, grouping, CSV import/export |

---

## 🛠️ Tools Used

- **SQL Server** — Database engine
- **SSMS** — SQL Server Management Studio
- **Python 3.12** — Programming language
- **Jupyter Notebook** — Python development environment
- **VS Code** — Code editor
- **Git & GitHub** — Version control and portfolio

---

## 📈 Journey Timeline

| Week | Focus |
|---|---|
| Week 1 | SQL Fundamentals (Days 1-4) |
| Week 2 | Advanced SQL + Hospital Project (Days 5-7) |
| Week 3 | Python Fundamentals |
| Week 4 | Pandas + Intermediate Python |
| Ongoing | DataCamp Scholarship — Data Engineering Track |

---

## 🎯 Next Steps

- [ ] Complete Python projects
- [ ] Learn cloud basics (Azure/AWS)
- [ ] Learn dbt (data transformation)
- [ ] Learn Apache Airflow (pipeline scheduling)
- [ ] Build end-to-end data pipeline project

---

*Started this journey after a rejection email. Built everything from zero. Still going.* 💪
